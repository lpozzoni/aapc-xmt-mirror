/**
 * This is a dummy xmtc.h file to be used when converting programs
 * from XMTC to OpenMP code.   */

#ifndef __XMTC_H__
#define __XMTC_H__

#ifdef __XMTC_2_OPENMP__
int $;
#endif

#define printSTR(x) printf(x)

#define printINT(x) printf("%d",x)

#endif
