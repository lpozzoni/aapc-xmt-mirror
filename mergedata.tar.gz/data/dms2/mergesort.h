/****************************************
 Automatically Generated Header File


          DO NOT MODIFY 

 Contains following Variables : 

Name      : A
Type      : int
Dimension : 1
Size [0]  : 4096
Source    : A.txt

Name      : R
Type      : int
Dimension : 1
Size [0]  : 4096
Source    : 0

****************************************/
extern int    A[4096];
extern int A_dim0_size;

extern int    R[4096];
extern int R_dim0_size;

#define n 4096
#define logn 12

