/****************************************
 Automatically Generated Header File


          DO NOT MODIFY 

 Contains following Variables : 

Name      : A
Type      : int
Dimension : 1
Size [0]  : 131072
Source    : A.txt

Name      : R
Type      : int
Dimension : 1
Size [0]  : 131072
Source    : 0

****************************************/
extern int    A[131072];
extern int A_dim0_size;

extern int    R[131072];
extern int R_dim0_size;

#define n 131072
#define logn 17

