/****************************************
 Automatically Generated Header File


          DO NOT MODIFY 

 Contains following Variables : 

Name      : X
Type      : int
Dimension : 1
Size [0]  : 65536
Source    : X.txt

Name      : Y
Type      : int
Dimension : 1
Size [0]  : 65536
Source    : Y.txt

Name      : R
Type      : int
Dimension : 1
Size [0]  : 131072
Source    : 0

****************************************/
extern int    X[65536];
extern int X_dim0_size;

extern int    Y[65536];
extern int Y_dim0_size;

extern int    R[131072];
extern int R_dim0_size;

#define k 65536
#define logk 16

