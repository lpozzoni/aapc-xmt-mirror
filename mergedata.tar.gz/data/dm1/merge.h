/****************************************
 Automatically Generated Header File


          DO NOT MODIFY 

 Contains following Variables : 

Name      : X
Type      : int
Dimension : 1
Size [0]  : 128
Source    : X.txt

Name      : Y
Type      : int
Dimension : 1
Size [0]  : 128
Source    : Y.txt

Name      : R
Type      : int
Dimension : 1
Size [0]  : 256
Source    : 0

****************************************/
extern int    X[128];
extern int X_dim0_size;

extern int    Y[128];
extern int Y_dim0_size;

extern int    R[256];
extern int R_dim0_size;

#define k 128
#define logk 7

