/****************************************
 Automatically Generated Header File


          DO NOT MODIFY 

 Contains following Variables : 

Name      : X
Type      : int
Dimension : 1
Size [0]  : 2048
Source    : X.txt

Name      : Y
Type      : int
Dimension : 1
Size [0]  : 2048
Source    : Y.txt

Name      : R
Type      : int
Dimension : 1
Size [0]  : 4096
Source    : 0

****************************************/
extern int    X[2048];
extern int X_dim0_size;

extern int    Y[2048];
extern int Y_dim0_size;

extern int    R[4096];
extern int R_dim0_size;

#define k 2048
#define logk 11

